package OS;

import java.io.IOException;

public class OSTest {

	public static void main(String[] args) throws IOException {
		RunAble<Tasks> operatingSystem = new RunAble<>();
		operatingSystem.run();

	}

}
