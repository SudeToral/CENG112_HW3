package OS;

import java.util.NoSuchElementException;

public class PriorityQueue<T extends Comparable<?super T>> implements IPriorityQueue<T>{
	private Node head;

	
	public class Node {
	    private T value;
	    private int priority;
	    private Node next;

	    public Node(T value, int priority) {
	        this.value = value;
	        this.priority = priority;
	        this.next = null;
	    }

	    public T getValue() {
	        return value;
	    }

	    public int getPriority() {
	        return priority;
	    }

	    public Node getNext() {
	        return next;
	    }

	    public void setNext(Node next) {
	        this.next = next;
	    }
	}


	public PriorityQueue() {
	    head = null;
	    }
	    

	    private Node getNodeBefore(T anEntry,int priority) { 
		    if (head == null) {
		        return null; 
		    }
			Node currentNode = head;
			Tasks tempentry = (Tasks) anEntry;
			Tasks tempcurrentnode =(Tasks) currentNode.getValue();
			Node nodeBefore = null;
			while ((currentNode != null) & (tempentry.comparePriority(tempcurrentnode)) >= 0){
				nodeBefore = currentNode;
				currentNode = currentNode.getNext();
				if (currentNode == null) {
					break;
				}
				tempcurrentnode =(Tasks) currentNode.getValue();

				}
				return nodeBefore;
		}
	    @Override
		public void enqueue(T value, int priority) {
	        Node newNode = new Node(value, priority);
	        Node nodeBefore = getNodeBefore(value,priority);
	        if (isEmpty() || (nodeBefore) == null){
	            newNode.setNext(head);
	            head = newNode;
	        } else {
	        	Node NodeAfter = nodeBefore.getNext();
				newNode.setNext(NodeAfter);
				nodeBefore.setNext(newNode);}

	    }
		@Override
	    public T dequeue() {
	        if (isEmpty()) {
	            throw new NoSuchElementException("Priority queue is empty");
	        }

	        T value = head.getValue();
	        head = head.getNext();
	        return value;
	    }
	    @Override
	    public T peek() {
	        if (isEmpty()) {
	            throw new NoSuchElementException("Priority queue is empty");
	        }

	        return head.getValue();
	    }

		@Override
		public void printpriorityQueue() {
	        Node current = head;
	        while (current != null) {
	            System.out.println(current.value);
	            current = current.next;
			
		}
	    
	}   
	    @Override
	    public boolean isEmpty() {
	        return head == null;
	    }


}


