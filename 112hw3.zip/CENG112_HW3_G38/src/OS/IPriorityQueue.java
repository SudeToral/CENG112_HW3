package OS;

public interface IPriorityQueue<T> {
	public boolean isEmpty();
	public void enqueue(T value, int priority);
	 public T dequeue();
	 public T peek();
	 public void printpriorityQueue();



	
	
	
}
