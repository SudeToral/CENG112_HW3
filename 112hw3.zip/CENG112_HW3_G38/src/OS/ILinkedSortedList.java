package OS;

public interface ILinkedSortedList<T> {
	public void add(T entry);
	public boolean remove(T anEntry);
	public int numberOfEntries();
	void printLinkedList();
	public T[] toArray();
	

}
