package OS;

public class Pile<T extends Comparable<?super T>> implements IPile<T>{
	T[] stack;
	private int top;

	@SuppressWarnings("unchecked")
	public Pile(int length) {
		T[] temp = (T[]) new Comparable[length];
		stack = temp;
		top = 0;
			
		}

	@Override
	public void push(T entry) {
		if (stack[0] == null) {
			stack[top] = entry;}
		else {
			@SuppressWarnings("unchecked")
			T[] popentrys = (T[]) new Comparable[stack.length];
			int index = 0;
			boolean ww = false;
			T temp = getbeforeEntryforTasks(entry);
			while (peek() != temp ) {
				ww = true;
				popentrys[index] = pop();
				index++;
				if (top == -1) {
					break;
				}}
			stack[top + 1] = entry;
			top++;
			if (ww) {
			int tempindex = index - 1;
			for (int i = tempindex ; i >= 0 ; i--) {
				stack[top + 1] = popentrys[i];
				tempindex--;
				top++;
				}}}
		}

		
	@Override
		public T pop() {
			T topx = stack[top];
			stack[top] = null;
			top--;
			return topx;
			}

	
		@Override
		public T peek() {
			return stack[top];
		}
		
		@Override
		public boolean isEmpty() {
			return stack[0] == null;
		}
		
		
	public T getbeforeEntryforTasks(T anEntry) {
		int index = 0;
		Tasks tempAnEntry = (Tasks) anEntry;
		Tasks beforeentry = (Tasks) stack[index];
		while(beforeentry != null && tempAnEntry.compareBurstTime(beforeentry) > 0 ) {
			if (stack[index] == null){
				return stack[top];
			}
			index++;
			beforeentry = (Tasks) stack[index];
		} 
		if(index == 0) {
			return null;
		}
		else {
		return stack[index - 1];}}
		
		
	public void printpile() {
    for (int i = stack.length - 1; i > -1 ; i-- ) {
    	if (stack[i] == null) {
    		continue;
    	}
    	System.out.println(stack[i]);
    }

    }
	
	
	
}
