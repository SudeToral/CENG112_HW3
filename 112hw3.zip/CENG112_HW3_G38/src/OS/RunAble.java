package OS;

import java.io.IOException;

public class RunAble<T> {

	public int definepriorty(T task) {
		Tasks temptask = (Tasks) task;
		int priorityResult = 0;
		if (temptask.getTaskType().equals("security management")){
			priorityResult = 6;}
		if (temptask.getTaskType().equals("process management")) {
			priorityResult = 5;}
		if (temptask.getTaskType().equals("memory management")) {
			priorityResult = 4;}
		if (temptask.getTaskType().equals("user management")) {
			priorityResult = 3;}
		if (temptask.getTaskType().equals("device management")) {
			priorityResult = 2;}
		if (temptask.getTaskType().equals("file management")) {
			priorityResult = 1;}
		return priorityResult;
		
			
		}
	
	public IPile<T> createAPile(ILinkedSortedList<T> list ){
		int pilesize = list.numberOfEntries();
		@SuppressWarnings("unchecked")
		IPile<T> pile = (IPile<T>) new Pile<>(pilesize);
		for(T task : list.toArray()) {
			pile.push(task);
		}
			return pile;
	}
	
	
	public IPriorityQueue<T> createPriorityQueue(ILinkedSortedList<T> list ) {
		@SuppressWarnings("unchecked")
		IPriorityQueue<T> priorityLine = (IPriorityQueue<T>) new PriorityQueue<>();
		for(T task : list.toArray()) {
			Tasks temptask = (Tasks) task;
			temptask.setPriority(definepriorty(task));
			priorityLine.enqueue(task,temptask.getPriority());}
				return priorityLine;
		
	}
	
	public void remainingqueue(IPriorityQueue<T> priorityqueue) {
		for(int i = 0; i < 5 ; i++) {
			priorityqueue.dequeue();
			
		}
		
	}
	public void remainingpile(IPile<T> pile) {
		for(int i = 0; i < 5 ; i++) {
			pile.pop();
		}
	}
    

	
	@SuppressWarnings("unchecked")
	public void run() throws IOException {
		FileIO file = new FileIO();
		ILinkedSortedList<T> sortedTaskList = (ILinkedSortedList<T>) file.readTasks();
		System.out.println("TASKS");
		System.out.println();
		sortedTaskList.printLinkedList();
		System.out.println();
		IPriorityQueue<T>  priorityqueue = createPriorityQueue(sortedTaskList);
		IPile<T> pile = (createAPile(sortedTaskList));
		while (!priorityqueue.isEmpty()) {
			System.out.println("PRİORİTY QUEUE EXECUTED");
			priorityqueue.printpriorityQueue();
			System.out.println();
			System.out.println();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			remainingqueue(priorityqueue);
			System.out.println("SYSTEM CONTİNUE EXECUTİON.....");
			System.out.println();
			System.out.println();
			
			
		}
		while(!pile.isEmpty()) {
			System.out.println("PİLE EXECUTED");
			pile.printpile();
			System.out.println();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			remainingpile(pile);
			System.out.println("SYSTEM CONTİNUE EXECUTİON.....");
			System.out.println();
			System.out.println();
			
			
		}
		System.out.println("Pile and Priority Queue are not executed anymore.");
		System.out.println("EXECUTİON IS OVER");

		}
	}

