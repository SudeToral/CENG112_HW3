package OS;

public class SortedLinkedList<T extends Comparable<?super T>> implements ILinkedSortedList<T> {
	private Node firstNode;
	private int numberOfEntries;
	
	
	public SortedLinkedList() {
		firstNode = null;
		numberOfEntries = 0;
	
	}

	 class Node{
		private T data;
		private Node next;
		
		private Node(T data) {
			this(data ,null);
		}

		public Node(T data, Node nextNode) {
			this.data = data;
			this.next = nextNode;
		}

		public T getData() {
			return data;
		}


		public void setData(T data) {
			this.data = data;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
		
		
	}
	
	private Node getNodeBefore(T anEntry) { 
	    if (firstNode == null) {
	        return null; // Return null for an empty list
	    }
		Node currentNode = firstNode;
		Node nodeBefore = null;
		while ((currentNode != null) & (anEntry.compareTo(currentNode.getData()) > 0)){
			nodeBefore = currentNode;
			currentNode = currentNode.getNext();
			if (currentNode == null) {
				break;
			}
		
		}
		return nodeBefore;
	}

	@Override
	public void add(T entry) {
		Node newNode = new Node(entry);
		Node nodeBefore = getNodeBefore(entry);
		if ( isEmpty() || (nodeBefore) == null) {
			newNode.setNext(firstNode);
			firstNode = newNode;
		
		
		}
		else {
			Node NodeAfter = nodeBefore.getNext();
			newNode.setNext(NodeAfter);
			nodeBefore.setNext(newNode);}
			numberOfEntries++;
		
	}

	@Override
		public boolean remove(T entry) {
		    if (isEmpty()) {
		        return false;
		    }

		    if (firstNode.getData().compareTo(entry) == 0) {
		        firstNode = firstNode.getNext();
		        numberOfEntries--;
		        return true;
		    }

		    Node previousNode = firstNode;
		    Node currentNode = firstNode.getNext();
		    while (currentNode != null) {
		        if (currentNode.getData().compareTo(entry) == 0) {
		            previousNode.setNext(currentNode.getNext());
		            numberOfEntries--;
		            return true;
		        }
		        previousNode = currentNode;
		        currentNode = currentNode.getNext();
		    }

		    return false;
		}

	
	public boolean isEmpty() {
		return numberOfEntries == 0;
	}
	
	public int numberOfEntries() {
		return numberOfEntries;
	}
	
	 @SuppressWarnings("unchecked")
	public T[] toArray() {
		   T[] temp = (T[]) new Comparable[this.numberOfEntries()];
	        Node current = firstNode;
	        int index = 0;

	        while (current != null) {
	      
	            temp[index++] = current.getData();
	            current = current.getNext();
	          
	        }

	        return temp;
	    }


	@Override
	public void printLinkedList() {
		Node currentNode = firstNode;
	    while (currentNode != null) {
	        System.out.println(currentNode.getData().toString() + " ");
	        currentNode = currentNode.getNext();
	    }
	    System.out.println(); 
	}
	
	


		

}
