package OS;
import java.io.*;


public class FileIO {
	
	public ILinkedSortedList<Tasks> readTasks() throws IOException {
		ILinkedSortedList<Tasks> sortedTasksList = new SortedLinkedList<Tasks>();
		String line;
		FileReader freader = new FileReader("tasks.txt");
		@SuppressWarnings("resource")
		BufferedReader breader = new BufferedReader(freader);
		while((line = breader.readLine()) != null) {
			String[] a = line.split(",");
			Tasks task = new Tasks(a[0], a[1], a[2] , a[3]);
			sortedTasksList.add(task);
			}
	return sortedTasksList;
	
	}
}

