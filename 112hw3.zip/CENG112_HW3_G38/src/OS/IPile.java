package OS;

public interface IPile<T> {
	public void push(T entry);
	public T pop();
	public T peek();
	public void printpile();
	public boolean isEmpty();

	

}

