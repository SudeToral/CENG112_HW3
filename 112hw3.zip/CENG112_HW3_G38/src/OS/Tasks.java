package OS;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;



public class Tasks implements Comparable<Object> {
	private String taskType;
	private int burstTime;
	private LocalDate arrivalDate;
	private LocalTime arrivalTime;
	String formatDate;
	private int priority;

	
	public Tasks(String taskType, String burstTime, String arrivalDate, String arrivalTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("HH:mm");
		LocalDate arrivaldate = LocalDate.parse(arrivalDate, formatter);
		LocalTime arrivaltime = LocalTime.parse(arrivalTime,formatter2);
		this.burstTime = Integer.parseInt(burstTime);
		this.arrivalDate = arrivaldate;
		this.arrivalTime = arrivaltime;
		this.taskType = taskType;
		formatDate = arrivaldate.format(formatter);
	}

		public String getTaskType() {
		return taskType;
	}
		


	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}


	public int getBurstTime() {
		return burstTime;
	}


	public void setBurstTime(int burstTime) {
		this.burstTime = burstTime;
	}


	public LocalDate getArrivalDate() {
		return arrivalDate;
	}


	public void setArrivalDate(LocalDate arrivalDate) {
		this.arrivalDate = arrivalDate;
	}


	public LocalTime getArrivalTime() {
		return arrivalTime;
	}


	public void setArrivalTime(LocalTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	
	
	@Override
	public String toString() {
		return "Tasks [taskType=" + taskType + ", burstTime=" + burstTime + ", arrivalDate=" + formatDate
				+ ", arrivalTime=" + arrivalTime + "]";
	}
	
	@Override
	public int compareTo(Object o) {
		Tasks temp = (Tasks) o;
		if ((arrivalDate).compareTo(temp.arrivalDate) == 0 ) {
			return arrivalTime.compareTo(temp.arrivalTime);}
		return (arrivalDate).compareTo(temp.arrivalDate);
			
			
		}
	
	public int comparePriority(Object currentnode) {
		Tasks temp = (Tasks) currentnode;
		if ((arrivalDate).compareTo(temp.arrivalDate) == 0 ) {
			if (temp.priority - priority != 0) {
				return temp.priority - priority;}
			else {
				return arrivalTime.compareTo(temp.arrivalTime);
			}
		}
		else {
			return (arrivalDate).compareTo(temp.arrivalDate);
		}
	}
	
	public int compareBurstTime(Object o) {
		Tasks temp = (Tasks) o;
		if( temp.burstTime != burstTime ) {
			return  temp.burstTime - burstTime;
		}
		else {
			if ((arrivalDate).compareTo(temp.arrivalDate) != 0) {
				return (temp.arrivalDate).compareTo(arrivalDate);
			}
			else {
				return temp.arrivalTime.compareTo(arrivalTime);
			}
			
		}
	}


	public int getPriority() {
		return priority;
	}


	public void setPriority(int priority) {
		this.priority = priority;
	}
	}






	
	



