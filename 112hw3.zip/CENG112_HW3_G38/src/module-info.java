/**
 * 
 */
/**
 * @author sudetoral
 *
 */
module hey {
}